<?php
header('Content-Type: application/json');

$root = dirname(__DIR__, 2);
$blobRoot = $root . '/blob';
$metaRoot = $root . '/meta';
$envPath = $root . '/.env';

function respond_json($statusCode, $payload) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function load_config($envPath) {
    $defaultExts = 'jpg,jpeg,png,webp,gif';
    $env = @parse_ini_file($envPath);
    $key = ($env && isset($env['HALAL_BLOB_KEY'])) ? trim($env['HALAL_BLOB_KEY']) : '';
    return ['key' => $key];
}

function require_auth($expectedKey) {
    $headerKey = isset($_SERVER['HTTP_X_HALAL_BLOB_KEY']) ? trim($_SERVER['HTTP_X_HALAL_BLOB_KEY']) : '';
    $getKey = isset($_GET['key']) ? $_GET['key'] : '';
    $key = $headerKey !== '' ? $headerKey : $getKey;
    if ($expectedKey === '' || $key === '' || $key !== $expectedKey) {
        respond_json(403, ['success' => false, 'error' => ['code' => 'INVALID_KEY', 'message' => 'Forbidden']]);
    }
}

$cfg = load_config($envPath);
require_auth($cfg['key']);

$folder = isset($_GET['folder']) ? $_GET['folder'] : '';
$folder = trim($folder);
if ($folder !== '' && !preg_match('/^[A-Za-z0-9_\-\/]*$/', $folder)) {
    respond_json(400, ['success' => false, 'error' => ['code' => 'FOLDER_INVALID', 'message' => 'Invalid folder']]);
}
$folder = trim($folder, '/');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 50;
if ($page < 1) { $page = 1; }
if ($perPage < 1) { $perPage = 50; }

$dir = $blobRoot . ($folder ? ('/' . $folder) : '');
if (!is_dir($dir)) {
    respond_json(400, ['success' => false, 'error' => ['code' => 'FOLDER_INVALID', 'message' => 'Folder not found']]);
}

$entries = scandir($dir);
$files = [];
foreach ($entries as $name) {
    if ($name === '.' || $name === '..') { continue; }
    $full = $dir . '/' . $name;
    if (!is_file($full)) { continue; }
    $relativePath = ($folder ? ($folder . '/') : '') . $name;
    $url = 'https://blob.yourdomain.com/blob/' . $relativePath;
    $metaPath = $metaRoot . '/' . $relativePath . '.json';
    $meta = null;
    if (is_file($metaPath)) {
        $raw = @file_get_contents($metaPath);
        if ($raw !== false) {
            $dec = json_decode($raw, true);
            if (is_array($dec)) { $meta = $dec; }
        }
    }
    $files[] = ['path' => $relativePath, 'url' => $url, 'meta' => $meta];
}

usort($files, function($a, $b) { return strcmp($a['path'], $b['path']); });
$total = count($files);
$offset = ($page - 1) * $perPage;
if ($offset < 0) { $offset = 0; }
$paged = array_slice($files, $offset, $perPage);

respond_json(200, [
    'success' => true,
    'folder' => $folder,
    'page' => $page,
    'per_page' => $perPage,
    'total' => $total,
    'files' => $paged,
]);
