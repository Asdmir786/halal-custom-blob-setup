<?php
header('Content-Type: application/json');

$root = dirname(__DIR__, 2);
$blobRoot = $root . '/blob';
$metaRoot = $root . '/meta';
$envPath = $root . '/.env';

function respond_json($statusCode, $payload) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function load_config($envPath) {
    $defaultMaxMB = 5;
    $defaultExts = 'jpg,jpeg,png,webp,gif';
    $env = @parse_ini_file($envPath);
    $key = ($env && isset($env['HALAL_BLOB_KEY'])) ? trim($env['HALAL_BLOB_KEY']) : '';
    $maxMB = ($env && isset($env['HALAL_BLOB_MAX_MB']) && is_numeric($env['HALAL_BLOB_MAX_MB'])) ? (float)$env['HALAL_BLOB_MAX_MB'] : $defaultMaxMB;
    $maxBytes = (int)round($maxMB * 1024 * 1024);
    $allowedExt = ($env && isset($env['HALAL_BLOB_ALLOWED_EXT']) && is_string($env['HALAL_BLOB_ALLOWED_EXT']) && strlen($env['HALAL_BLOB_ALLOWED_EXT']) > 0) ? $env['HALAL_BLOB_ALLOWED_EXT'] : $defaultExts;
    $allowedExts = array_map('strtolower', array_filter(array_map('trim', explode(',', $allowedExt))));
    return ['key' => $key, 'maxBytes' => $maxBytes, 'allowedExts' => $allowedExts];
}

function require_auth($expectedKey) {
    $headerKey = isset($_SERVER['HTTP_X_HALAL_BLOB_KEY']) ? trim($_SERVER['HTTP_X_HALAL_BLOB_KEY']) : '';
    $getKey = isset($_GET['key']) ? $_GET['key'] : '';
    $key = $headerKey !== '' ? $headerKey : $getKey;
    if ($expectedKey === '' || $key === '' || $key !== $expectedKey) {
        respond_json(403, ['success' => false, 'error' => ['code' => 'INVALID_KEY', 'message' => 'Forbidden']]);
    }
}

$cfg = load_config($envPath);
require_auth($cfg['key']);

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    respond_json(400, ['success' => false, 'error' => ['code' => 'NO_FILE', 'message' => 'No file uploaded']]);
}

$folder = isset($_POST['folder']) ? $_POST['folder'] : '';
$folder = trim($folder);
if ($folder !== '' && !preg_match('/^[A-Za-z0-9_\-\/]*$/', $folder)) {
    respond_json(400, ['success' => false, 'error' => ['code' => 'FOLDER_INVALID', 'message' => 'Folder contains invalid characters']]);
}
$folder = trim($folder, '/');

$targetDir = $blobRoot . ($folder ? ('/' . $folder) : '');
if (!is_dir($targetDir)) {
    if (!mkdir($targetDir, 0755, true)) {
        respond_json(500, ['success' => false, 'error' => ['code' => 'SERVER_ERROR', 'message' => 'Failed to create target directory']]);
    }
}

$originalName = $_FILES['file']['name'];
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
$sizeBytes = isset($_FILES['file']['size']) ? (int)$_FILES['file']['size'] : 0;
$mime = isset($_FILES['file']['type']) ? $_FILES['file']['type'] : '';

$mimeMap = [
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'webp' => 'image/webp',
    'gif' => 'image/gif',
];
$allowedMimes = [];
foreach ($cfg['allowedExts'] as $e) {
    if (isset($mimeMap[$e])) { $allowedMimes[] = $mimeMap[$e]; }
}

if (!in_array($ext, $cfg['allowedExts'], true) || !in_array($mime, $allowedMimes, true)) {
    respond_json(400, ['success' => false, 'error' => ['code' => 'INVALID_TYPE', 'message' => 'Unsupported file type']]);
}

if ($sizeBytes > $cfg['maxBytes']) {
    respond_json(400, ['success' => false, 'error' => ['code' => 'FILE_TOO_LARGE', 'message' => 'File exceeds maximum allowed size']]);
}

$basename = bin2hex(random_bytes(16));
$filename = $basename . ($ext ? ('.' . $ext) : '');
$targetPath = $targetDir . '/' . $filename;

if (!move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
    respond_json(500, ['success' => false, 'error' => ['code' => 'SERVER_ERROR', 'message' => 'Failed to save file']]);
}

$relativePath = ($folder ? ($folder . '/') : '') . $filename;
$url = 'https://blob.yourdomain.com/blob/' . $relativePath;

$meta = [
    'path' => $relativePath,
    'url' => $url,
    'size_bytes' => $sizeBytes,
    'mime_type' => $mime,
    'original_name' => $originalName,
    'uploaded_at' => gmdate('c'),
    'client_ip' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
    'folder' => $folder,
];

$metaDir = $metaRoot . ($folder ? ('/' . $folder) : '');
if (!is_dir($metaDir)) { mkdir($metaDir, 0755, true); }
$metaPath = $metaDir . '/' . $filename . '.json';
if (@file_put_contents($metaPath, json_encode($meta, JSON_PRETTY_PRINT)) === false) {
    respond_json(500, ['success' => false, 'error' => ['code' => 'SERVER_ERROR', 'message' => 'Failed to write metadata']]);
}

respond_json(200, [
    'success' => true,
    'url' => $url,
    'filename' => $filename,
    'path' => $relativePath,
    'meta' => [
        'size_bytes' => $sizeBytes,
        'mime_type' => $mime,
        'uploaded_at' => $meta['uploaded_at'],
        'folder' => $folder,
        'original_name' => $originalName,
        'client_ip' => $meta['client_ip'],
    ],
]);
