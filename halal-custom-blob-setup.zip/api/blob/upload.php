<?php
header('Content-Type: application/json');

$root = dirname(__DIR__, 2);
$envPath = $root . '/.env';
$config = parse_ini_file($envPath);

$expectedKey = isset($config['HALAL_BLOB_KEY']) ? $config['HALAL_BLOB_KEY'] : null;
$key = isset($_GET['key']) ? $_GET['key'] : null;

if (!$expectedKey || !$key || $key !== $expectedKey) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['error' => 'No file uploaded']);
    exit;
}

$folder = isset($_POST['folder']) ? $_POST['folder'] : '';
$folder = preg_replace('/[^A-Za-z0-9_\-\\/]/', '', $folder);
$folder = trim($folder, '/');

$blobRoot = $root . '/blob';
$targetDir = $blobRoot . ($folder ? ('/' . $folder) : '');

if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

$originalName = $_FILES['file']['name'];
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
$basename = bin2hex(random_bytes(16));
$filename = $basename . ($ext ? ('.' . $ext) : '');

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $_FILES['file']['tmp_name']);
finfo_close($finfo);

$allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
if (!in_array($mime, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Unsupported file type']);
    exit;
}

$finalPath = $targetDir . '/' . $filename;
if (!move_uploaded_file($_FILES['file']['tmp_name'], $finalPath)) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to save file']);
    exit;
}

$relativePath = ($folder ? ($folder . '/') : '') . $filename;
$url = 'https://blob.yourdomain.com/blob/' . $relativePath;

echo json_encode([
    'success' => true,
    'url' => $url,
    'filename' => $filename,
    'path' => $relativePath
]);
