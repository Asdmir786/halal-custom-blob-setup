<?php
header('Content-Type: application/json');

$root = dirname(__DIR__, 2);
$envPath = $root . '/.env';

function respond_json($statusCode, $payload) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function load_config($envPath) {
    $env = @parse_ini_file($envPath);
    $key = ($env && isset($env['HALAL_BLOB_KEY'])) ? trim($env['HALAL_BLOB_KEY']) : '';
    return ['key' => $key];
}

function require_auth($expectedKey) {
    $headerKey = isset($_SERVER['HTTP_X_HALAL_BLOB_KEY']) ? trim($_SERVER['HTTP_X_HALAL_BLOB_KEY']) : '';
    $getKey = isset($_GET['key']) ? $_GET['key'] : '';
    $key = $headerKey !== '' ? $headerKey : $getKey;
    if ($expectedKey === '' || $key === '' || $key !== $expectedKey) {
        respond_json(403, ['success' => false, 'error' => ['code' => 'INVALID_KEY', 'message' => 'Forbidden']]);
    }
}

$cfg = load_config($envPath);
require_auth($cfg['key']);

respond_json(200, [
    'success' => true,
    'status' => 'ok',
    'php_version' => PHP_VERSION,
    'time' => gmdate('c'),
]);
